export interface projects{
    id: number,
    name:string,
    client:string,
    budget:number,
    startDate:Date,
    endDate:Date,
    country:string,
    status: string
}